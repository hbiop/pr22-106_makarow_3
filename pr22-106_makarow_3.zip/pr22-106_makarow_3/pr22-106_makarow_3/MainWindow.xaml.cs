﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr22_106_makarow_3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        bool FlagRazmer = false;
        bool FlagNachalo = false;
        bool FlagKonec = false;
        int[] array; 
        private void btn_sgenerirovat_Click(object sender, RoutedEventArgs e)
        {
            int Razmer;
            FlagRazmer = int.TryParse(TB_razmer.Text, out Razmer);
            int Nachalo;
            FlagNachalo = int.TryParse(TB_nachalo.Text, out Nachalo);
            int Konec;
            FlagKonec = int.TryParse(TB_konec.Text, out Konec);
            if (FlagRazmer && FlagNachalo && FlagKonec && Nachalo < Konec)
            {
                array = new int[Razmer];
                Random rnd = new Random();
                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = rnd.Next(Nachalo, Konec);
                }
                    tb_vivod_massiva.Text  = String.Join(" ", array);
            }
            else
            {
                if (Nachalo > Konec || Nachalo == Konec)
                {
                    MessageBox.Show("Начало диапозона должно быть меньше чем конец");
                    
                }
                else
                {
                    MessageBox.Show("Одна из веедённых строк не является целым числом");
                }
                FlagKonec = false;
                FlagNachalo = false;
                FlagRazmer = false;
            }

        }

        private void tb_vivod_sort_Click(object sender, RoutedEventArgs e)
        {
            int[] array2 = array;
            if(FlagKonec && FlagNachalo && FlagRazmer)
            {
                int a;
                int kol = 1;
                while (kol > 0)
                {
                    kol = 0;
                    for (int i = 0; i < array2.Length - 1; i++)
                    {
                        if (array2[i] % 2 != 0 && array2[i + 1] % 2 == 0)
                        {
                            a = array2[i];
                            array2[i] = array2[i + 1];
                            array2[i + 1] = a;
                            kol = kol + 1;
                        }
                    }
                }
                tb_vivod_massiva_sort.Text = String.Join(" ", array2);
            }
            else
            {
                MessageBox.Show("Массив для сортировки не был сгенерирован");
            }
        }
    }
}
